$(document).ready(function () {
    $("#menu").click(function () {
        $("#sidebar").slideToggle(1000);
    });
});