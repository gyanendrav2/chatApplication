<?php
$db = mysqli_connect("localhost","root","","messanger") or die("unable to connect");
?>